Type the following at first:(not case sensitive)
m - Matrix Operations
l - Linear Operations
t - Tensor Operations

Type help for further assistance!

After accessing mat> | lin> | ten> 
Continue with the operations as required
Note : If User do not know how to initiate operations, User might simply type "help" and enter | 
      take help from helpm.txt and helpt.txt

Note : Make sure to "exit" for clearing file data in order to avoid program malfunctions for the next time you use the 
       tool next time with fresh files.

**If the program malfunctions check the variablesm.txt and variablest.txt files created in Your (C:)drive
  and clear the file.